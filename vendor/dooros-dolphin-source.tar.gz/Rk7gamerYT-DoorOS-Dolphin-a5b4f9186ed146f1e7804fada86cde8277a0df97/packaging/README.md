# Dolphin Door OS

Prototype based on KDE Dolphin 26.08.1. Upstream source, LICENSES and every local source file are included in the resulting package. The window integration is GPL-2.0-or-later; upstream libraries retain their licenses.

The header mirrors the native tab bar. Dolphin owns folder pages, history, KIO jobs and the original tab context menu. The client-side window uses Qt's system move/resize requests, avoiding manual coordinate-based window movement on Wayland. Classic chrome can be restored by setting DOOROS_DOLPHIN_CLASSIC=1 before starting Dolphin, or IntegratedChrome=false in the DoorOS group of dolphinrc.

Build on Arch with scripts/build-dolphin.sh. PKGBUILD pins the KDE archive and all local inputs by SHA-256. PackageKit integration is explicitly disabled so optional builder packages do not create undeclared runtime dependencies.

Experimental limitations: tab dragging to detach a separate window and file dropping on the mirrored tabs need dedicated forwarding. The upstream view, keyboard shortcuts and tab context menu remain available. Validate compositor move/resize, small-window layout and theme switching before promotion to a stable repository.