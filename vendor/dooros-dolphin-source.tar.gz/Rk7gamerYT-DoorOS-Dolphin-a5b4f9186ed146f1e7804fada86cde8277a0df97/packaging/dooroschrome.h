// SPDX-FileCopyrightText: 2026 Door OS contributors
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
#include <QApplication>
#include <QContextMenuEvent>
#include <QCursor>
#include <QHBoxLayout>
#include <QMainWindow>
#include <QMenu>
#include <QMouseEvent>
#include <QPointer>
#include <QPainterPath>
#include <QRegion>
#include <QPainter>
#include <QGraphicsEffect>
#include <QSignalBlocker>
#include <QTabBar>
#include <QTimer>
#include <QToolButton>
#include <QWindow>
#include <functional>
#include <KLocalizedString>

class DoorOsRoundedEffect final : public QGraphicsEffect {
public:
    explicit DoorOsRoundedEffect(QMainWindow *window) : QGraphicsEffect(window), m_window(window) {}
protected:
    void draw(QPainter *painter) override {
        QPoint offset;
        const QPixmap content = sourcePixmap(Qt::LogicalCoordinates, &offset, QGraphicsEffect::NoPad);
        painter->save();
        if (!m_window->isMaximized() && !m_window->isFullScreen()) {
            QPainterPath outline;
            outline.addRoundedRect(QRectF(m_window->rect()), 10, 10);
            painter->setRenderHint(QPainter::Antialiasing);
            painter->setClipPath(outline);
        }
        painter->drawPixmap(offset, content);
        painter->restore();
    }
private:
    QMainWindow *m_window;
};

// Presentation-only tab proxy: Dolphin still owns pages, history and file jobs.
class DoorOsChrome final : public QWidget {
public:
    DoorOsChrome(QMainWindow *window, QTabBar *nativeTabs,
                 std::function<void()> newTab, std::function<void(int)> closeTab)
        : QWidget(window), m_window(window), m_native(nativeTabs), m_closeTab(std::move(closeTab))
    {
        setObjectName(QStringLiteral("doorosHeader"));
        setFixedHeight(42);
        setAutoFillBackground(true);
        m_window->setGraphicsEffect(new DoorOsRoundedEffect(m_window));
        setStyleSheet(QStringLiteral("QTabBar::tab { min-width: 140px; padding: 7px 12px; border: 0; border-top-left-radius: 8px; border-top-right-radius: 8px; } QTabBar::tab:selected { background: palette(mid); } QToolButton { border: 0; border-radius: 5px; } QToolButton:hover { background: palette(mid); }"));
        auto *row = new QHBoxLayout(this);
        row->setContentsMargins(8, 3, 0, 0);
        row->setSpacing(3);
        m_tabs = new QTabBar(this);
        m_tabs->setDocumentMode(true);
        m_tabs->setExpanding(false);
        m_tabs->setMovable(true);
        m_tabs->setTabsClosable(true);
        m_tabs->setElideMode(Qt::ElideRight);
        m_tabs->setAccessibleName(i18n("Folder tabs"));
        m_tabs->installEventFilter(this);
        row->addWidget(m_tabs);
        auto *add = button(QStringLiteral("+"), i18n("New Tab"));
        connect(add, &QToolButton::clicked, this, [newTab] { newTab(); });
        row->addWidget(add);
        row->addStretch(1);
        auto *minimize = button(QString::fromUtf8("−"), i18n("Minimize"));
        auto *maximize = button(QString::fromUtf8("□"), i18n("Maximize or Restore"));
        auto *close = button(QString::fromUtf8("×"), i18n("Close Window"));
        close->setStyleSheet(QStringLiteral("QToolButton:hover { background: #c42b1c; color: white; }"));
        connect(minimize, &QToolButton::clicked, window, &QWidget::showMinimized);
        connect(maximize, &QToolButton::clicked, this, [this] { toggleMaximized(); });
        connect(close, &QToolButton::clicked, window, &QWidget::close);
        row->addWidget(minimize); row->addWidget(maximize); row->addWidget(close);
        connect(m_tabs, &QTabBar::currentChanged, this, [this](int index) {
            if (index >= 0) m_native->setCurrentIndex(index);
        });
        connect(m_tabs, &QTabBar::tabCloseRequested, this, [this](int index) { m_closeTab(index); });
        connect(m_tabs, &QTabBar::tabMoved, this, [this](int from, int to) { m_native->moveTab(from, to); });
        connect(m_native, &QTabBar::currentChanged, this, [this] { synchronize(); });
        connect(m_native, &QTabBar::tabMoved, this, [this] { synchronize(); });
        m_tabs->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(m_tabs, &QWidget::customContextMenuRequested, this, [this](const QPoint &point) {
            const int index = m_tabs->tabAt(point);
            if (index < 0) return;
            QContextMenuEvent event(QContextMenuEvent::Mouse, m_native->tabRect(index).center(), m_tabs->mapToGlobal(point));
            QApplication::sendEvent(m_native, &event);
        });
        // Names/icons can change asynchronously as KIO resolves locations.
        auto *refresh = new QTimer(this);
        refresh->setInterval(200);
        connect(refresh, &QTimer::timeout, this, [this] { synchronize(); });
        refresh->start();
        qApp->installEventFilter(this);
        synchronize();
    }
    ~DoorOsChrome() override { qApp->removeEventFilter(this); }
protected:
    void mousePressEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton && m_window->windowHandle()) {
            m_window->windowHandle()->startSystemMove();
            event->accept();
        } else QWidget::mousePressEvent(event);
    }
    void mouseDoubleClickEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton) { toggleMaximized(); event->accept(); }
        else QWidget::mouseDoubleClickEvent(event);
    }
    void contextMenuEvent(QContextMenuEvent *event) override {
        QMenu menu(this);
        menu.addAction(i18n("Minimize"), m_window, &QWidget::showMinimized);
        menu.addAction(i18n("Maximize or Restore"), this, [this] { toggleMaximized(); });
        menu.addSeparator();
        menu.addAction(i18n("Close Window"), m_window, &QWidget::close);
        menu.exec(event->globalPos());
    }
    bool eventFilter(QObject *watched, QEvent *event) override {
        if (watched == m_window && event->type() == QEvent::Paint) {
            QPainter background(m_window);
            background.fillRect(m_window->rect(), m_window->palette().brush(QPalette::Window));
        }
        if (watched == m_tabs && event->type() == QEvent::MouseButtonRelease) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::MiddleButton) {
                const int index = m_tabs->tabAt(mouse->position().toPoint());
                if (index >= 0) { m_closeTab(index); return true; }
            }
        }
        auto *widget = qobject_cast<QWidget *>(watched);
        if (watched == m_window && (event->type() == QEvent::Resize || event->type() == QEvent::WindowStateChange)) {
            if (m_window->isMaximized() || m_window->isFullScreen()) m_window->clearMask();
            else {
                QPainterPath outline;
                outline.addRoundedRect(QRectF(m_window->rect()), 10, 10);
                m_window->setMask(QRegion(outline.toFillPolygon().toPolygon()));
            }
        }
        if (!widget || widget->window() != m_window || m_window->isMaximized() || m_window->isFullScreen()) return false;
        if (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::MouseMove) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            const QPoint point = m_window->mapFromGlobal(mouse->globalPosition().toPoint());
            Qt::Edges edges;
            if (point.x() < 6) edges |= Qt::LeftEdge;
            if (point.x() >= m_window->width()-6) edges |= Qt::RightEdge;
            if (point.y() < 6) edges |= Qt::TopEdge;
            if (point.y() >= m_window->height()-6) edges |= Qt::BottomEdge;
            if (event->type() == QEvent::MouseMove) {
                if (m_cursorOwner && (m_cursorOwner != widget || !edges)) {
                    m_cursorOwner->setCursor(m_savedCursor);
                    m_cursorOwner.clear();
                }
                if (edges) {
                    if (!m_cursorOwner) { m_cursorOwner = widget; m_savedCursor = widget->cursor(); }
                    const bool horizontal = edges.testFlag(Qt::LeftEdge) || edges.testFlag(Qt::RightEdge);
                    const bool vertical = edges.testFlag(Qt::TopEdge) || edges.testFlag(Qt::BottomEdge);
                    const bool diagonal = (edges.testFlag(Qt::LeftEdge) && edges.testFlag(Qt::TopEdge))
                        || (edges.testFlag(Qt::RightEdge) && edges.testFlag(Qt::BottomEdge));
                    widget->setCursor(horizontal && vertical ? (diagonal ? Qt::SizeFDiagCursor : Qt::SizeBDiagCursor)
                                      : horizontal ? Qt::SizeHorCursor : Qt::SizeVerCursor);
                }
                return false;
            }
            if (mouse->button() != Qt::LeftButton || !m_window->windowHandle()) return false;
            if (edges && m_window->windowHandle()->startSystemResize(edges)) return true;
        }
        return false;
    }
private:
    QToolButton *button(const QString &text, const QString &label) {
        auto *result = new QToolButton(this);
        result->setText(text); result->setToolTip(label); result->setAccessibleName(label);
        result->setAutoRaise(true); result->setFixedSize(42, 36);
        return result;
    }
    void toggleMaximized() { if (m_window->isMaximized()) m_window->showNormal(); else m_window->showMaximized(); }
    void synchronize() {
        if (m_window->isMaximized() || m_window->isFullScreen()) m_window->clearMask();
        else {
            QPainterPath outline;
            outline.addRoundedRect(QRectF(m_window->rect()), 10, 10);
            const QRegion rounded(outline.toFillPolygon().toPolygon());
            if (m_window->mask() != rounded) m_window->setMask(rounded);
        }
        QSignalBlocker guard(m_tabs);
        while (m_tabs->count() > m_native->count()) m_tabs->removeTab(m_tabs->count()-1);
        while (m_tabs->count() < m_native->count()) m_tabs->addTab(QString());
        for (int i=0; i<m_native->count(); ++i) {
            if (m_tabs->tabText(i) != m_native->tabText(i)) m_tabs->setTabText(i, m_native->tabText(i));
            if (m_tabs->tabIcon(i).cacheKey() != m_native->tabIcon(i).cacheKey()) m_tabs->setTabIcon(i, m_native->tabIcon(i));
            m_tabs->setTabToolTip(i, m_native->tabToolTip(i));
        }
        m_tabs->setCurrentIndex(m_native->currentIndex());
        m_tabs->setMaximumWidth(qMax(180, m_window->width()-240));
        m_native->hide();
    }
    QMainWindow *m_window;
    QTabBar *m_native;
    QTabBar *m_tabs;
    QPointer<QWidget> m_cursorOwner;
    QCursor m_savedCursor;
    std::function<void(int)> m_closeTab;
};
