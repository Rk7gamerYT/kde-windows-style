# SPDX-License-Identifier: GPL-2.0-or-later
"""Apply the Door OS window integration to pinned Dolphin 26.08.1."""
from pathlib import Path
import shutil
import sys
source=Path(sys.argv[1])
recipe=Path(__file__).resolve().parent
shutil.copyfile(recipe/'dooroschrome.h',source/'src/dooroschrome.h')
p=source/'src/dolphinmainwindow.cpp'
s=p.read_text()
anchor='#include "dolphinmainwindow.h"'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n#include "dooroschrome.h"\n#include <QLineEdit>')
anchor='    Q_INIT_RESOURCE(dolphin);'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+r'''
    // Request an alpha surface before KDE creates the native Wayland window.
    if (!qEnvironmentVariableIsSet("DOOROS_DOLPHIN_CLASSIC")
        && KConfigGroup(KSharedConfig::openConfig(), "DoorOS").readEntry("IntegratedChrome", true)) {
        setAttribute(Qt::WA_TranslucentBackground, true);
    }
''')
anchor='    connect(GeneralSettings::self(), &GeneralSettings::tabBarChanged, this, &DolphinMainWindow::slotTabBarChanged);'
assert s.count(anchor)==1
integration=r'''
    // Door OS client-side chrome. The traditional window remains available.
    if (!usePhoneUi && !qEnvironmentVariableIsSet("DOOROS_DOLPHIN_CLASSIC")
        && KConfigGroup(KSharedConfig::openConfig(), "DoorOS").readEntry("IntegratedChrome", true)) {
        setWindowFlag(Qt::FramelessWindowHint, true);
        setAttribute(Qt::WA_TranslucentBackground, true);
        auto *chrome = new DoorOsChrome(this, m_tabWidget->tabBar(),
            [this] { m_tabWidget->openNewActivatedTab(); },
            [this](int index) { m_tabWidget->closeTab(index); });
        auto *caption = new KToolBar(QStringLiteral("doorosCaption"), this);
        caption->setWindowTitle(i18n("Window tabs"));
        caption->setMovable(false);
        caption->setFloatable(false);
        caption->setContentsMargins(0, 0, 0, 0);
        chrome->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        caption->addWidget(chrome);
        insertToolBar(toolBar(), caption);
        insertToolBarBreak(toolBar());
        auto *actions = toolBar(QStringLiteral("doorosActions"));
        removeToolBar(actions);
        addToolBarBreak(Qt::TopToolBarArea);
        addToolBar(Qt::TopToolBarArea, actions);
        actions->setMovable(false);
        actions->setFloatable(false);
        toolBar()->setMovable(false);
        toolBar()->setFloatable(false);
        // Session restoration runs after construction. Rebuild the three rows
        // on the event loop so a saved toolbar state cannot merge them again.
        QTimer::singleShot(0, this, [this, caption, actions] {
            auto *navigation = toolBar();
            removeToolBar(caption);
            removeToolBar(navigation);
            removeToolBar(actions);
            addToolBar(Qt::TopToolBarArea, caption);
            addToolBarBreak(Qt::TopToolBarArea);
            addToolBar(Qt::TopToolBarArea, navigation);
            addToolBarBreak(Qt::TopToolBarArea);
            addToolBar(Qt::TopToolBarArea, actions);
            caption->show();
            navigation->show();
            actions->show();
        });
        auto *search = new QLineEdit(toolBar());
        search->setClearButtonEnabled(true);
        search->setAccessibleName(i18n("Search in this folder"));
        search->setPlaceholderText(i18n("Search in this folder"));
        search->setMinimumWidth(220);
        search->setMaximumWidth(420);
        search->addAction(QIcon::fromTheme(QStringLiteral("edit-find")), QLineEdit::LeadingPosition);
        toolBar()->insertWidget(actionCollection()->action(QStringLiteral("toggle_search")), search);
        connect(search, &QLineEdit::returnPressed, this, [this, search] {
            if (search->text().trimmed().isEmpty()) return;
            Search::DolphinQuery query(m_activeViewContainer->url(), m_activeViewContainer->url());
            query.setSearchLocations(Search::SearchLocations::FromHere);
            query.setSearchThrough(Search::SearchThrough::FileNames);
            query.setSearchTerm(search->text());
            search->setProperty("doorosSearchBase", query.searchPath());
            changeUrl(query.toUrl());
        });
        connect(search, &QLineEdit::textEdited, this, [this, search](const QString &text) {
            const QUrl base = search->property("doorosSearchBase").toUrl();
            if (text.isEmpty() && base.isValid() && Search::isSupportedSearchScheme(m_activeViewContainer->url().scheme())) changeUrl(base);
        });
        connect(this, &DolphinMainWindow::urlChanged, search, [search](const QUrl &url) {
            if (!Search::isSupportedSearchScheme(url.scheme())) search->clear();
            else search->setText(Search::DolphinQuery(url, url).searchTerm());
        });
    }
'''
s=s.replace(anchor,anchor+'\n'+integration)
p.write_text(s,encoding='utf-8',newline='\n')
# The embedded UI works without relying on an overlay in an older live ISO.
shutil.copyfile(recipe/'dolphinui.rc',source/'src/dolphinui.rc')
