// SPDX-License-Identifier: GPL-2.0-or-later
#include <QtTest>
#include "../../src/dooroschrome.h"
class ChromeTest : public QObject {
 Q_OBJECT
private Q_SLOTS:
 void roundedWindowRendering() {
  QMainWindow window;
  window.setAttribute(Qt::WA_TranslucentBackground);
  window.resize(300,200);
  QTabBar native(&window);
  native.addTab(QStringLiteral("Home"));
  DoorOsChrome header(&window,&native,[] {},[](int) {});
  window.show();
  QTest::qWait(250);
  const QImage painted=window.grab().toImage();
  QVERIFY(painted.pixelColor(150,100).alpha()>0);
  QCOMPARE(painted.pixelColor(0,0).alpha(),0);
 }
 void windowControls() {
  QMainWindow window;
  QTabBar native(&window);
  native.addTab(QStringLiteral("Home"));
  DoorOsChrome header(&window, &native, [] {}, [](int) {});
  QToolButton *minimize=nullptr, *maximize=nullptr, *close=nullptr;
  for (auto *button:header.findChildren<QToolButton *>()) {
   if(button->text()==QString::fromUtf8("−")) minimize=button;
   if(button->text()==QString::fromUtf8("□")) maximize=button;
   if(button->text()==QString::fromUtf8("×")) close=button;
  }
  QVERIFY(minimize && maximize && close);
  window.show();
  minimize->click();
  QVERIFY(window.isMinimized());
  window.showNormal();
  maximize->click();
  QVERIFY(window.isMaximized());
  maximize->click();
  QVERIFY(!window.isMaximized());
  close->click();
  QVERIFY(!window.isVisible());
 }
 void tabSynchronization() {
  QMainWindow window;
  QTabBar native(&window);
  native.addTab(QStringLiteral("Home"));
  int closed=-1;
  DoorOsChrome header(&window, &native,
   [&native] { native.addTab(QStringLiteral("New")); },
   [&native,&closed](int index) { closed=index; native.removeTab(index); });
  auto *tabs=header.findChild<QTabBar *>();
  QVERIFY(tabs);
  QCOMPARE(tabs->count(),1);
  native.addTab(QStringLiteral("Documents"));
  QTRY_COMPARE(tabs->count(),2);
  tabs->setCurrentIndex(1);
  QCOMPARE(native.currentIndex(),1);
  tabs->moveTab(1,0);
  QCOMPARE(native.tabText(0),QStringLiteral("Documents"));
  native.setTabText(0,QStringLiteral("Renamed"));
  QTRY_COMPARE(tabs->tabText(0),QStringLiteral("Renamed"));
  QToolButton *add=nullptr;
  for (auto *button:header.findChildren<QToolButton *>()) if(button->text()==QStringLiteral("+")) add=button;
  QVERIFY(add);
  add->click();
  QTRY_COMPARE(tabs->count(),3);
  QMetaObject::invokeMethod(tabs,"tabCloseRequested",Qt::DirectConnection,Q_ARG(int,1));
  QCOMPARE(closed,1);
  QTRY_COMPARE(tabs->count(),2);
  QVERIFY(!native.isVisible());
 }
};
QTEST_MAIN(ChromeTest)
#include "chrome-test.moc"
