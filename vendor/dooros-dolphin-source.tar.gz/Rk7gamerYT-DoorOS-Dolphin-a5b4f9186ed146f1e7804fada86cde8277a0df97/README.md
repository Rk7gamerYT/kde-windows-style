# Dolphin do Door OS

Gerenciador de arquivos do Door OS, baseado no KDE Dolphin 26.08.1. Este repositório contém os fontes completos dessa versão e as alterações do Door OS já aplicadas: abas integradas, navegação e ações em linhas separadas, busca permanente e cantos arredondados.

## Compilar

No Arch Linux, a receita `packaging/PKGBUILD` declara dependências e checksums. Ela baixa o arquivo KDE original e aplica os arquivos de `packaging/` de maneira reproduzível:

```sh
cd packaging
makepkg --syncdeps
```

Para compilar diretamente os fontes já modificados deste repositório, instale as dependências da receita e execute:

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_INSTALL_PREFIX=/usr -DBUILD_TESTING=OFF -DCMAKE_DISABLE_FIND_PACKAGE_PackageKitQt6=ON
cmake --build build --parallel 2
```

Não execute apply-dooros.py novamente sobre os fontes deste checkout: eles já estão modificados. O script serve para o arquivo upstream original usado pela receita. Os temas e ícones do Door OS são integrados pelo repositório principal da distro.

## Testes da interface

```sh
cmake -S tests/dooros-chrome -B build-chrome -G Ninja
cmake --build build-chrome
ctest --test-dir build-chrome --output-on-failure
```

O modo clássico pode ser ativado com `DOOROS_DOLPHIN_CLASSIC=1`. O funcionamento de KIO, arquivos, histórico e abas continua baseado no Dolphin. Arrastar uma aba para destacá-la e soltar arquivos nas abas espelhadas ainda exigem integração específica.

## Origem e licença

Base: KDE Dolphin 26.08.1, arquivo upstream SHA-256 `f5635feff84e7070d35342d6defb46e9b42ff1c44e3896635f4bd9f43da947c1`.

Os créditos e avisos upstream permanecem nos fontes, COPYING e LICENSES. As alterações do Door OS são GPL-2.0-or-later; componentes upstream preservam suas respectivas licenças. Repositório principal: https://github.com/Rk7gamerYT/DoorOS.
